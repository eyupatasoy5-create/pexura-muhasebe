const assert=require('node:assert/strict');
const m=require('../stock-math.js');
assert.deepEqual(m.summary(14652,6455,139),{toplam:14652,brutSatilan:6455,iade:139,netSatilan:6316,kalan:8336});
assert.equal(m.stockValue(8336,.93),7752.48);
assert.deepEqual(m.summary(10,3,1),{toplam:10,brutSatilan:3,iade:1,netSatilan:2,kalan:8});
assert.equal(m.summary(2,5,0).kalan,0);
console.log('stock-math: OK');
